package jardinbotanico;

public class TestJardinBotanico {
    public static void main(String[] args) {
        // Crear un jardín botánico
        JardinBotanico jardin = new JardinBotanico("Rosalia");

        // Crear algunas plantas
        Planta roble = new Arbol("Roble", "Zona Norte", "Templado", 25.5);
        Planta sauce = new Arbol("Sauce", "Zona Sur", "Frío", 20.0);
        Planta lavanda = new Arbusto("Lavanda", "Zona Este", "Mediterráneo", 7);
        Planta margarita = new Flor("Margarita", "Zona Oeste", "Cálido", Temporada.PRIMAVERA);

        // Agregar plantas al jardín
        try {
            jardin.agregarPlanta(roble);
            jardin.agregarPlanta(sauce);
            jardin.agregarPlanta(lavanda);
            jardin.agregarPlanta(margarita);
        } catch (PlantaDuplicadaException e) {
            System.out.println(e.getMessage());
        }

        // Mostrar las plantas registradas
        jardin.mostrarPlantas();

        // Intentar agregar una planta duplicada (con el mismo nombre y ubicación)
        Planta robleDuplicado = new Arbol("Roble", "Zona Norte", "Templado", 30.0);
        try {
            jardin.agregarPlanta(robleDuplicado); // Debería lanzar una excepción
        } catch (PlantaDuplicadaException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Podar plantas
        jardin.podarPlantas();
    }
}