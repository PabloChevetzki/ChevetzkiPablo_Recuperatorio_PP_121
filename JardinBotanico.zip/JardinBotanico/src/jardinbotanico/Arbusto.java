package jardinbotanico;

public class Arbusto extends Planta implements Podable {
    private int densidadFollaje;
    
    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) {
        super(nombre, ubicacion, clima);
        this.densidadFollaje = densidadFollaje;
    }
    
    public void podar() {
        System.out.println("Podando el arbusto: " + nombre);
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("Arbusto - Nombre: " + nombre + ", Ubicación: " + ubicacion + ", Clima: " + clima + ", Densidad de Follaje: " + densidadFollaje);
    }
}