package jardinbotanico;

// Excepción personalizada para manejar plantas duplicadas
public class PlantaDuplicadaException extends RuntimeException {
    private static String MESSAGE = "LA PLANTA YA EXISTE"; // Este es el mensaje de error
        
    public PlantaDuplicadaException() {
            super(MESSAGE); // Llama al constructor de la clase padre con el mensaje
    } 
}