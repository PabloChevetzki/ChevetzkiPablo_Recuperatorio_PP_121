package jardinbotanico;

import java.util.ArrayList;
import java.util.List;

// Clase que representa el jardín botánico, que contiene las plantas
public class JardinBotanico {
    private List<Planta> plantas; // Lista de plantas en el jardín
    private String nombre;

    public JardinBotanico(String nombre) {
        this.plantas = new ArrayList<>(); // Inicia la lista de plantas
        this.nombre = nombre;
    }

    public void agregarPlanta(Planta p) {
        verificarAgregacion(p); // Verifica si la planta ya existe en el jardín
        plantas.add(p);
    }

    private void verificarAgregacion(Planta p) {
        if (p == null) {  // Si la planta es nula, lanza una excepción
            throw new NullPointerException("La planta no puede ser nula.");
        }
        if (plantas.contains(p)) {  // Si la planta ya existe en la lista, lanza una excepción personalizada
            throw new PlantaDuplicadaException();
        }
    }

    public void mostrarPlantas() {
        if (plantas.size() > 0) {  // Si hay plantas en el jardín
            for (Planta p : plantas) {
                p.mostrarInfo(); // Mostrar la información de cada planta
            }
        } else {
            System.out.println("No hay plantas registradas.");
        }
    }

    // Método para podar las plantas que son podables
    public void podarPlantas() {
        if (plantas.size() > 0) {
            for (Planta p : plantas) {
                if (p instanceof Podable) { // Si la planta es podable
                    ((Podable) p).podar();
                } else {
                    System.out.println("La planta " + p.getNombre() + " no es podable.");
                }
            }
        }
    }
}