package jardinbotanico;

public enum Temporada {
    PRIMAVERA, VERANO, OTOÑO, INVIERNO;
}