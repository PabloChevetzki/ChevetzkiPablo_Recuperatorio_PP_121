package jardinbotanico;

public class Flor extends Planta {
    private Temporada temporadaFlorecimiento;
    
    public Flor(String nombre, String ubicacion, String clima, Temporada temporadaFlorecimiento) {
        super(nombre, ubicacion, clima);
        this.temporadaFlorecimiento = temporadaFlorecimiento;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("Flor - Nombre: " + nombre + ", Ubicación: " + ubicacion + ", Clima: " + clima + ", Temporada de Florecimiento: " + temporadaFlorecimiento);
    }
}