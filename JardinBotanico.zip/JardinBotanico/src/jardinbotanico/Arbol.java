package jardinbotanico;

public class Arbol extends Planta implements Podable {
    private double alturaMaxima;
    
    public Arbol(String nombre, String ubicacion, String clima, double alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }
    
    public void podar() {
        System.out.println("Podando el árbol: " + nombre);
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("Árbol - Nombre: " + nombre + ", Ubicación: " + ubicacion + ", Clima: " + clima + ", Altura Máxima: " + alturaMaxima);
    }
}